from flask import Flask, render_template, request, redirect,jsonify
from psycopg2 import connect, extras

app = Flask(__name__)

# Datos para la conexión a la base de datos
host = "localhost"
port = 5432
username = "postgres"
password = "1234"
dbname = "latratoria"

# Función para la conexión a la base de datos
def connect_database():
    conn = connect(host=host, port=port, user=username, password=password, dbname=dbname)
    return conn

# Ruta raíz - página de inicio
@app.route("/")
def home():
    return render_template("index.html")
# Ruta reserva
@app.route('/Reservas')
def reservas():
    return render_template('formulario')

# Ruta para el ingreso del administrador
@app.route("/administrador", methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == "latratoria" and password == "1234":
            return redirect('/registro')
        else:
            return render_template("login.html", mostrar_error=True)
    else:
        return render_template('login.html', mostrar_error=False)

# Ruta para el listado de registros
@app.route("/registro", methods=['GET'])
def registros():
    conn = connect_database()
    cursor = conn.cursor(cursor_factory = extras.RealDictCursor)
    cursor.execute("SELECT c.nombre, c.apellido, c.idcedula, c.telefono, a.nombreambiente, r.idreserva, r.cantidadepersonas FROM comensales c, reservas r, ambientes a WHERE a.idambiente = r.idambiente AND c.idcedula = r.idcedula")
    datos = cursor.fetchall()
    conn.close()
    cursor.close()
    print(datos)
    return render_template("registro.html", datos=datos)


@app.route("/formulario", methods=['GET', 'POST'])
def formulario():
    if request.method == 'GET':
        return render_template('formulario.html')
    
    if request.method == 'POST':
        nombre = request.form['nombre']
        apellido = request.form['apellido']
        telefono = request.form['telefono']
        correo = request.form['correo']
        alergias = request.form['alergias']
        fecha_reserva = request.form['fecha']
        cantidad_personas = request.form['cantidad']
        id_ambiente = request.form['ambiente']
        conn = connect_database()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO comensales (nombre, apellido, telefono, correo, descripciondealergias) VALUES (%s, %s, %s, %s, %s) RETURNING idcedula",
                       (nombre, apellido, telefono, correo, alergias))
        id_comensal = cursor.fetchone()[0]
        cursor.execute("INSERT INTO reservas (fecha, cantidadpersonas, idcedula, idambiente) VALUES (%s, %s, %s, %s)",
                       (fecha_reserva, cantidad_personas, id_comensal, id_ambiente))
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return redirect('/formulario.html')


if __name__ == "__main__":
    app.run(debug=True)


